import React from "react";
import Header from "./Header";
import SubHeader from "./SubHeader";
import './Header.css'

const Home = (props) => {
  return (
    <div>
     <Header />
     <SubHeader />
    </div>
  );
};

export default Home;
