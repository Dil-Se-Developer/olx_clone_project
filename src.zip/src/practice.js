// const [errMsg, setErrMsg] = useState("")
    // const validate = (event) => {
    //     let { value, type } = event.target
    //     if (type === "email") {
    //         const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    //         if (!value) {
    //             setErrMsg("Emailid is required!")
    //         } else if (!regex.test(value)) {
    //             setErrMsg("This is not a valid email format!")

    //         } else {
    //             setErrMsg("")
    //         }
    //     } else if (type === "number") {
    //         if (!value) {
    //             setErrMsg("Mobileno is required!")
    //         } else if (value.length !== 10) {
    //             setErrMsg("Mobileno cannot exceed more than 10 characters")
    //         } else {
    //             setErrMsg("")
    //         }
    //     } else if (type === "password") {
    //         if (!value) {
    //             setErrMsg("Password is required!")

    //         } else if (value.length < 4) {
    //             setErrMsg("Password must be more than 4 characters")

    //         } else if (value.length > 10) {
    //             setErrMsg("Password cannot exceed more than 10 characters")
    //         } else {
    //             setErrMsg("")

    //         }
    //     }
    //     else {
    //         if (value === "") {
    //             setErrMsg(`${inputName} is required`)

    //         } else {
    //             setErrMsg("")
    //         }
    //     }

    // }




    // {Object.keys(formErrors).length === 0 && isSubmit ? (
    //     <div>Signed in successfully</div>
    //   ) : (
    //     <pre>{JSON.stringify(formValues, undefined, 2)}</pre>
    //   )}


